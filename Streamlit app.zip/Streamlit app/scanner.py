import requests
from bs4 import BeautifulSoup
import urllib.parse
import re
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Set
import sys
import colorama
import sqlite3
import json
from datetime import datetime

class WebSecurityScanner:
    def __init__(self, target_url: str, max_depth: int = 3):
        self.target_url = target_url
        self.max_depth = max_depth
        self.visited_urls: Set[str] = set()
        self.vulnerabilities: List[Dict] = []
        self.session = requests.Session()

    def normalize_url(self, url: str) -> str:
        parsed = urllib.parse.urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

    def crawl(self, url: str, depth: int = 0) -> None:
        if depth > self.max_depth or url in self.visited_urls:
            return
        try:
            self.visited_urls.add(url)
            response = self.session.get(url, verify=False, timeout=5)
            soup = BeautifulSoup(response.text, 'html.parser')
            for link in soup.find_all('a', href=True):
                next_url = urllib.parse.urljoin(url, link['href'])
                if next_url.startswith(self.target_url):
                    self.crawl(next_url, depth + 1)
        except Exception:
            pass

    def check_sql_injection(self, url: str) -> None:
        sql_payloads = ["'", "1' OR '1'='1", "' OR 1=1--", "' UNION SELECT NULL--"]
        try:
            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)
            for payload in sql_payloads:
                for param in params:
                    test_url = url.replace(f"{param}={params[param][0]}", f"{param}={payload}")
                    response = self.session.get(test_url, timeout=5)
                    if any(err in response.text.lower() for err in ['sql', 'mysql', 'sqlite', 'postgresql', 'oracle']):
                        self.vulnerabilities.append({'type': 'SQL Injection', 'url': url, 'parameter': param, 'payload': payload})
        except Exception:
            pass

    def check_xss(self, url: str) -> None:
        xss_payloads = ["<script>alert('XSS')</script>", "<img src=x onerror=alert('XSS')>", "javascript:alert('XSS')"]
        try:
            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)
            for payload in xss_payloads:
                for param in params:
                    test_url = url.replace(f"{param}={params[param][0]}", f"{param}={urllib.parse.quote(payload)}")
                    response = self.session.get(test_url, timeout=5)
                    if payload in response.text:
                        self.vulnerabilities.append({'type': 'Cross-Site Scripting (XSS)', 'url': url, 'parameter': param, 'payload': payload})
        except Exception:
            pass

    def check_sensitive_info(self, url: str) -> None:
        patterns = {
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
            'api_key': r'api[_-]?key[_-]?([\'"|`])([a-zA-Z0-9]{32,45})\1'
        }
        try:
            response = self.session.get(url, timeout=5)
            for info_type, pattern in patterns.items():
                for match in re.finditer(pattern, response.text):
                    self.vulnerabilities.append({'type': 'Sensitive Information Exposure', 'url': url, 'info_type': info_type, 'pattern': pattern})
        except Exception:
            pass

    def quickscan(self) -> List[Dict]:
        self.visited_urls.add(self.target_url)
        self.check_sql_injection(self.target_url)
        self.check_xss(self.target_url)
        self.check_sensitive_info(self.target_url)
        return self.vulnerabilities

    def deepscan(self) -> List[Dict]:
        self.crawl(self.target_url)
        with ThreadPoolExecutor(max_workers=5) as executor:
            for url in self.visited_urls:
                executor.submit(self.check_sql_injection, url)
                executor.submit(self.check_xss, url)
                executor.submit(self.check_sensitive_info, url)
        return self.vulnerabilities

# ── CLI Execution Block ───────────────────────────────────────────────────────
if __name__ == "__main__":
    colorama.init()

    if len(sys.argv) < 3 or sys.argv[1] not in ("--quickscan", "--deepscan"):
        print("Usage: python scanner.py --quickscan|--deepscan <target_url> [username]")
        print("Note: [username] is optional and defaults to 'admin' for database logging.")
        sys.exit(1)

    mode = sys.argv[1]
    target_url = sys.argv[2]
    username = sys.argv[3] if len(sys.argv) > 3 else "admin" 

    scanner = WebSecurityScanner(target_url)
    scan_name = "Quick Scan" if mode == "--quickscan" else "Deep Scan"
    
    print(f"\n{colorama.Fore.BLUE}[{scan_name}] {target_url}{colorama.Style.RESET_ALL}\n")

    vulnerabilities = scanner.quickscan() if mode == "--quickscan" else scanner.deepscan()

    for vuln in vulnerabilities:
        print(f"{colorama.Fore.RED}[VULNERABILITY FOUND]{colorama.Style.RESET_ALL}")
        for key, value in vuln.items():
            print(f"{key.capitalize()}: {value}")
        print()

    print(f"\n{colorama.Fore.GREEN}Scan Complete!{colorama.Style.RESET_ALL}")
    print(f"Total URLs scanned: {len(scanner.visited_urls)}")
    print(f"Vulnerabilities found: {len(vulnerabilities)}")

    # ── Database Logging Logic ──
    try:
        conn = sqlite3.connect("websec.db")
        c = conn.cursor()
        
        # Verify user exists to get their ID
        c.execute("SELECT id FROM users WHERE username=?", (username,))
        user_row = c.fetchone()

        if user_row:
            user_id = user_row[0]
            scan_type_str = "quick" if mode == "--quickscan" else "deep"
            
            # Calculate specific vulnerability counts
            sql_cnt = sum(1 for v in vulnerabilities if "SQL" in v.get("type", ""))
            xss_cnt = sum(1 for v in vulnerabilities if "XSS" in v.get("type", ""))
            info_cnt = sum(1 for v in vulnerabilities if "Sensitive" in v.get("type", ""))
            total_vulns = len(vulnerabilities)
            
            # Insert with the new columns
            c.execute("""INSERT INTO scans 
                         (user_id, target_url, scan_type, timestamp, vulns_json, endpoints_count, sqli_count, xss_count, info_count, total_vulns) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                      (user_id, target_url, scan_type_str, datetime.now(), json.dumps(vulnerabilities), len(scanner.visited_urls), sql_cnt, xss_cnt, info_cnt, total_vulns))
            conn.commit()
            print(f"{colorama.Fore.CYAN}[+] Results successfully logged to database under user: '{username}'{colorama.Style.RESET_ALL}\n")
        else:
            print(f"{colorama.Fore.YELLOW}[!] User '{username}' not found in database. Results NOT saved.{colorama.Style.RESET_ALL}\n")
            
        conn.close()
    except sqlite3.OperationalError:
         print(f"{colorama.Fore.YELLOW}[!] websec.db schema mismatch. Ensure you deleted the old database file so the new columns could be created.{colorama.Style.RESET_ALL}\n")